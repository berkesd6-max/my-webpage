/* Profilbeállítások: helyi mentés, avatar, szín és bábu skin */
(() => {
  const $ = id => document.getElementById(id);
  const key = 'sz_profile_settings_v1';
  const defaults = {name:'Player', avatar:'', language:'en', color:'#c9a24d', skin:'classic', sudokuTheme:'default'};
  let data = {...defaults};
  try { data = {...defaults, ...JSON.parse(localStorage.getItem(key) || '{}')}; } catch {}
  if (data.name === 'Játékos') data.name = 'Player';
  if (data.color === '#8b5cf6') data.color = '#c9a24d';
  if (data.language === 'hu') data.language = 'en';
  const emoji = {wK:'♔',wQ:'♕',wR:'♖',wB:'♗',wN:'♘',wP:'♙',bK:'♚',bQ:'♛',bR:'♜',bB:'♝',bN:'♞',bP:'♟'};
  function paintAvatar() {
    const a=$('profile-avatar');
    if (!a) return;
    a.style.backgroundImage = data.avatar ? `url("${data.avatar}")` : 'none';
    a.textContent = data.avatar ? '' : (data.name.trim()[0] || '♟').toUpperCase();
    $('profile-trigger-name').textContent = data.name || 'Profile';
  }
  function apply() {
    document.documentElement.style.setProperty('--primary', data.color);
    document.body.classList.remove('sudoku-theme-teal','sudoku-theme-purple','sudoku-theme-gold');
    if (data.sudokuTheme !== 'default') document.body.classList.add('sudoku-theme-'+data.sudokuTheme);
    paintAvatar();
    const name=$('player-name-input'); if(name && name.value !== data.name) name.value=data.name;
    if (window.net && data.name && window.net.userName !== data.name) window.net.setUserName(data.name);
    document.documentElement.lang=data.language;
    document.querySelectorAll('[data-color]').forEach(b=>b.classList.toggle('chosen',b.dataset.color===data.color));
  }
  function applySkin() {
    const board=$('chess-board'); if(!board || !window.app?.chess) return;
    board.querySelectorAll('.chess-square').forEach(sq=>{
      const r=Number(sq.dataset.row), c=Number(sq.dataset.col), p=window.app.chess.engine.board[r]?.[c];
      const el=sq.querySelector('.chess-piece'); if(!el || !p) return;
      el.classList.toggle('emoji-skin',data.skin==='emoji');
      el.classList.toggle('minimal-skin',data.skin==='minimal');
      if(data.skin==='emoji') el.textContent=emoji[p[0]+p[1]] || '♟';
      else if(data.skin==='classic') {
        const pieceKey=p[0]+p[1];
        if(typeof PIECE_SVGS!=='undefined' && PIECE_SVGS[pieceKey]) el.innerHTML=PIECE_SVGS[pieceKey];
      } else {
        const pieceKey=p[0]+p[1];
        if(typeof PIECE_SVGS!=='undefined' && PIECE_SVGS[pieceKey]) el.innerHTML=PIECE_SVGS[pieceKey];
      }
    });
  }
  function open() {
    $('profile-name').value=data.name;
    $('profile-language').value=data.language;
    $('piece-skin').value=data.skin;
    document.querySelectorAll('[data-color]').forEach(b=>b.classList.toggle('chosen',b.dataset.color===data.color));
    $('profile-modal').style.display='flex';
  }
  document.addEventListener('DOMContentLoaded', () => {
    $('btn-profile')?.addEventListener('click',open);
    $('profile-close')?.addEventListener('click',()=>$('profile-modal').style.display='none');
    $('profile-save')?.addEventListener('click',()=>{
      data.name=$('profile-name').value.trim() || 'Player';
      data.language=$('profile-language').value;
      data.skin=$('piece-skin').value;
      try { localStorage.setItem(key,JSON.stringify(data)); } catch {}
      apply(); $('profile-modal').style.display='none';
      if(window.app?.currentView==='chess') { window.app.chess.renderBoard(); applySkin(); }
    });
    $('profile-avatar-file')?.addEventListener('change',e=>{
      const file=e.target.files?.[0]; if(!file) return;
      if(file.size>1_500_000){alert('Please choose an image no larger than 1.5 MB.');e.target.value='';return;}
      const reader=new FileReader(); reader.onload=()=>{data.avatar=reader.result;paintAvatar();}; reader.readAsDataURL(file);
    });
    document.querySelectorAll('[data-color]').forEach(b=>b.addEventListener('click',()=>{data.color=b.dataset.color;apply();}));
    // Sudoku palette controls added to profile
    const label=document.createElement('label'); label.className='profile-label'; label.textContent='Sudoku grid color';
    const sel=document.createElement('select'); sel.className='form-control'; sel.id='sudoku-theme-select';
    [['default','Default'],['teal','Teal'],['purple','Purple'],['gold','Gold']].forEach(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;sel.appendChild(o);});
    sel.value=data.sudokuTheme; sel.addEventListener('change',()=>{data.sudokuTheme=sel.value;apply();try{localStorage.setItem(key,JSON.stringify(data));}catch{}});
    $('profile-save').before(label,sel);
    // Reapply piece styling after every board render.
    if(window.app?.chess) {
      const chess=window.app.chess, original=chess.renderBoard.bind(chess);
      chess.renderBoard=function(){original();applySkin();};
    }
    if(window.app) {
      const app=window.app, originalShowModal=app.showModal.bind(app);
      app.showModal=function(title,message) {
        originalShowModal(title,message);
        const card=document.querySelector('#info-modal .modal-card');
        if(!card) return;
        card.querySelectorAll('.quick-play-again').forEach(b=>b.remove());
        if(/victory|congratulations|solved together|checkmate|time's up/i.test(title)) {
          const btn=document.createElement('button');
          btn.className='btn btn-primary quick-play-again';
          btn.textContent='Play again';
          btn.style.marginTop='12px';
          btn.addEventListener('click',()=>{
            app.hideModal();
            if(app.activeGame==='sudoku' || app.currentView==='sudoku') {
              app.sudoku.startNewGame({difficulty:app.sudoku.difficulty,mode:app.sudoku.gameMode});
            } else if(app.currentView==='chess') {
              app.chess.startNewGame({mode:app.chess.gameMode,difficulty:app.chess.aiDifficulty,playerColor:app.chess.playerColor,timeControl:app.chess.timeControl});
            }
          });
          card.appendChild(btn);
        }
      };
    }
    apply();
  });
})();