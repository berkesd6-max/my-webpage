# Chess & Sudoku Online 🎮

A modern, desktop- and mobile-friendly web game platform with **Chess** and **Sudoku** in one clean interface. Play solo (against an AI), in local 2-player mode, or in **real-time online multiplayer** with your friends!

---

## 🚀 How to start the game

### Option 1: Quick start (recommended)
Double-click the **`inditas.bat`** file in the folder!
- It starts the local Python server and automatically opens the game in your default browser.
- The terminal also shows your local Wi-Fi IP address (e.g. `http://192.168.1.15:8000`), which you can type into a phone or tablet on the same Wi-Fi network!

### Option 2: Open directly
Simply open **`index.html`** in any modern browser (Chrome, Edge, Firefox, Safari).

---

## ♟️ Chess features

- **Full rule set**:
  - Official piece movement
  - Kingside (O-O) and queenside (O-O-O) castling
  - En passant
  - Pawn promotion (Queen, Rook, Bishop, Knight)
  - Automatic detection of check, checkmate and draws (stalemate, 50-move rule, insufficient material)
- **Game modes**:
  - **Vs Computer (AI)**: 3 difficulty levels (Beginner, Intermediate, and Master level with a Minimax algorithm using Alpha-Beta pruning and piece-square tables).
  - **Local 2 Players**: Play against each other on one screen and keyboard.
  - **Online Multiplayer**: Via room code or shareable link. Real-time move sync, chess clock (1, 5 or 10 minutes), resignation, and in-game chat.
- **Visuals**:
  - Crisp, scalable vector (SVG) pieces
  - Highlighted legal moves and captures
  - Last-move highlight
  - Pulsing red indicator for a king in check
  - Captured pieces and algebraic move history
  - Board flipping
- **Full-page LED glow**: the main menu has a cursor-following LED glow and seasonal particles (Halloween, Christmas, Summer, Autumn, Classic) across the whole page.

---

## 🔢 Sudoku features

- **Generator and checker**:
  - 9x9 puzzles guaranteed to have a unique, valid solution
  - 4 difficulty levels: **Easy**, **Medium**, **Hard**, **Master**
  - Real-time conflict and mistake detection (duplicates highlighted in red)
- **Convenience tools**:
  - **Pencil Notes**: Enter candidate numbers in any empty cell (shown as a small 3x3 grid).
  - **Number highlighting**: Click a number to light up all identical numbers on the board.
  - **Related cell highlighting**: The row, column and 3x3 box of the active cell are softly highlighted.
  - **Undo** and **Hint** buttons.
  - Number pad and physical keyboard support (1-9, Backspace, arrow keys).
- **Online modes**:
  - **Duel / Race**: Both players get the same puzzle. A real-time progress bar at the top of the screen shows how many cells your opponent has solved. First to finish wins!
  - **Co-op**: Two players solve the same board together in real time. You can see each other's cursor, numbers and notes!

---

## 🌐 How to play online with a friend

1. Open the game, then click **"Create Online Room"** or **"Online Duel & Co-op"**.
2. Set your options (color, time or Sudoku mode), then click **"Create Room"**.
3. A **6-character room code** (e.g. `AB12CD`) and a direct link appear.
4. **Share the code or link with your friend**:
   - If they click the link, they join your room automatically.
   - Or they can enter the code in the "Got a room code?" box on the main menu!
5. Thanks to WebRTC (PeerJS), the connection is made directly between the two browsers, so **no external server, port forwarding or router settings are needed**!

---

## ⌨️ Keyboard shortcuts (Sudoku)

- **1-9**: Enter a number in the selected cell (or add a note in notes mode)
- **Del / Backspace / 0**: Erase the selected cell
- **Arrow keys (↑, ↓, ←, →)**: Move around the board
- **N**: Toggle notes (pencil) mode
- **Z or Ctrl+Z**: Undo the last action
- **H**: Ask for a hint (reveals one cell)

---

## 🔊 Built-in sounds
The game uses the Web Audio API, so no external audio files are needed. Use the 🔊 button in the header to mute the sound at any time.

Have fun and good luck! 🏆
