@echo off
title Chess and Sudoku Online
cd /d "%~dp0"

echo ===================================================
echo     Starting Chess and Sudoku Online...
echo ===================================================

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py server.py
    goto end
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python server.py
    goto end
)

echo Python not found, opening directly in the browser...
start index.html

:end
